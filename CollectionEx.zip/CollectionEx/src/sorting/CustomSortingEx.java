package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomSortingEx {
	
	public static void main(String[] args) {
		
		User user = new User();
		user.setUserId(1001);
		user.setAddress("pune");
		user.setContactNumber(10888888888l);
		user.setGender("male");
		user.setUserName("Ajay");
		
		User user2 = new User();
		user2.setUserId(1002);
		user2.setAddress("mumbai");
		user2.setContactNumber(10888888888l);
		user2.setGender("female");
		user2.setUserName("Swati");
		
		User user3 = new User();
		user3.setUserId(1000);
		user3.setAddress("nagpur");
		user3.setContactNumber(10888888888l);
		user3.setGender("male");
		user3.setUserName("Bijay");
		
		User user4 = new User();
		user4.setUserId(1004);
		user4.setAddress("Solapur");
		user4.setContactNumber(10888888888l);
		user4.setGender("male");
		user4.setUserName("Xpertit");
		
		List<User> userList = new ArrayList<>();
		userList.add(user);
		userList.add(user2);
		userList.add(user3);
		userList.add(user4);
		
		Collections.sort(userList);
		
		System.out.println(userList.toString());
		
		
	}

}
