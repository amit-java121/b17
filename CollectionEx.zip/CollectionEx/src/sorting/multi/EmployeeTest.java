package sorting.multi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeTest {
	
	public List<Employee> prepareEmpData() {
		Employee employee = new Employee();
		employee.setEmpId(1000);
		employee.setEmpName("amit");
		employee.setEmpAddress("pune");
		employee.setContactNumber(191919991);
		
		Employee employee2 = new Employee();
		employee2.setEmpId(1000);
		employee2.setEmpName("ajay");
		employee2.setEmpAddress("pune");
		employee2.setContactNumber(191919991);
		
		Employee employee3 = new Employee();
		employee3.setEmpId(1002);
		employee3.setEmpName("sanjay");
		employee3.setEmpAddress("nagpur");
		employee3.setContactNumber(191919991);
		
		Employee employee4 = new Employee();
		employee4.setEmpId(1001);
		employee4.setEmpName("swati");
		employee4.setEmpAddress("mumbai");
		employee4.setContactNumber(191919991);
		
		List<Employee> listOfEmp = new ArrayList<>();
		listOfEmp.add(employee);
		listOfEmp.add(employee2);
		listOfEmp.add(employee3);
		listOfEmp.add(employee4);
		
		return listOfEmp;
	}
	
	
	public void sortEmpData() {
		List<Employee> empList = prepareEmpData();
		Collections.sort(empList,new EmployeeIdSorting());
		System.out.println("sorting on employee id :: "+empList.toString());
		Collections.sort(empList,new EmployeeNameSorting());
		System.out.println("sorting on employee name "+empList.toString());
	}
	
	
	public static void main(String[] args) {
		EmployeeTest et = new EmployeeTest();
		et.sortEmpData();
	}

}
