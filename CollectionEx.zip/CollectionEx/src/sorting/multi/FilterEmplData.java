package sorting.multi;

import java.util.ArrayList;
import java.util.List;

public class FilterEmplData {
	
	public List<Employee> filterEmpDataByCityName(String cityName) {
		
		EmployeeTest et = new EmployeeTest();
		List<Employee> empList = et.prepareEmpData();
		
		List<Employee> fliteredEmpList = new ArrayList<Employee>();
		//write logic to filter the data
		for(Employee emp:empList) {
			
			if(emp.getEmpAddress().equals(cityName)) {
				fliteredEmpList.add(emp);
			}
		}
		
		return fliteredEmpList;
	}
	
	
	public static void main(String[] args) {
		FilterEmplData fet = new FilterEmplData();
		List<Employee> filteredList = fet.filterEmpDataByCityName("delhi");
		//will print city data
		System.out.println(filteredList.toString());
	}

}
