package sorting;

import java.util.HashMap;
import java.util.TreeMap;

import map.User;

public class SortingEx1 {
	
public TreeMap<User, Long> sortUserData() {
		
		User user = new User();
		user.setAdhaarNumber(10000001014l);
		user.setAddress("pune");
		user.setContactNumber(10888888888l);
		user.setGender("male");
		user.setUserName("Ajay");
		
		User user2 = new User();
		user2.setAdhaarNumber(10000001011l);
		user2.setAddress("mumbai");
		user2.setContactNumber(10888888888l);
		user2.setGender("female");
		user2.setUserName("Swati");
		
		User user3 = new User();
		user3.setAdhaarNumber(10000001012l);
		user3.setAddress("nagpur");
		user3.setContactNumber(10888888888l);
		user3.setGender("male");
		user3.setUserName("Bijay");
		
		User user4 = new User();
		user4.setAdhaarNumber(10000001013l);
		user4.setAddress("Solapur");
		user4.setContactNumber(10888888888l);
		user4.setGender("male");
		user4.setUserName("Xpertit");
		
		//HashMap<Long, User> userMap = new HashMap<Long, User>();
		
		TreeMap<User, Long> treeMap = new TreeMap<User, Long>();
		
//		treeMap.put(user.getAdhaarNumber(), user);
//		treeMap.put(user2.getAdhaarNumber(), user2);
//		treeMap.put(user3.getAdhaarNumber(), user3);
//		treeMap.put(user4.getAdhaarNumber(), user4);
		
		treeMap.put(user, user.getAdhaarNumber());
		treeMap.put(user2, user2.getAdhaarNumber());
		treeMap.put(user3, user3.getAdhaarNumber());
		treeMap.put(user4, user4.getAdhaarNumber());
		
		System.out.println(treeMap.toString());
		
		return treeMap;
	}

	public static void main(String[] args) {
		SortingEx1 se = new SortingEx1();
		se.sortUserData();
	}

}
