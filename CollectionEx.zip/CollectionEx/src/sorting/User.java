package sorting;

public class User implements Comparable<User>{
	
	private int userId;
	private String userName;
	private String gender;
	private String address;
	private long contactNumber;
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", gender=" + gender + ", address="
				+ address + ", contactNumber=" + contactNumber + "]";
	}
	
	
	@Override
	public int compareTo(User user) {
		
		if(user.getUserId() < userId) {
			return 1;
		}else if(user.getUserId() > userId) {
			return -1;
		}
//		else if(user.getUserId() == userId) {
//			return 0;
//		}
		
		return 0;
	}
	
	
	

}
