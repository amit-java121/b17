package com;

import java.util.ArrayList;

public class GetEmpData {
	
	public void printEmp() {
		EmployeeData ed = new EmployeeData();
		ArrayList<Employee> listOfEmployee = ed.empData();
		
		System.out.println(listOfEmployee.toString());
		
	}

	
	public static void main(String[] args) {
		GetEmpData ged = new GetEmpData();
		ged.printEmp();
	}
}
