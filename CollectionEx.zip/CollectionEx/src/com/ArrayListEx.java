package com;

import java.util.ArrayList;

public class ArrayListEx {
	
	public static void main(String[] args) {
		
		ArrayList<String> arrayList = new ArrayList<String>();
		
		arrayList.add("amit");
		arrayList.add("xyz");
		arrayList.add("xpertit");
		arrayList.add("abc");
		arrayList.add("amit");
	
		
		
		for(int i=0;i<arrayList.size(); i++) {
			String name = (String)arrayList.get(i);
			
			System.out.println(name);
		}
		
		
	}

}
