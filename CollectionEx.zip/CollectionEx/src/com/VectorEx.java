package com;

import java.util.Vector;

public class VectorEx {
	
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();
		vector.addElement("xpertit");
		vector.addElement("xpertit1");
		vector.addElement("xpertit2");
		
		System.out.println(vector.capacity());
		
		System.out.println(vector);
	}

}
