package com;

import java.util.LinkedList;

public class LinkedListEx {
	
	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<>();
		linkedList.add("xpertit");
		linkedList.add("abc");
		linkedList.add("pqr");
		linkedList.push("abc1");
		
		System.out.println(linkedList);
	}

}
