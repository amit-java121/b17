package com;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx2 {
	
	public static void main(String[] args) {
		
		ArrayList<String> arrayList = new ArrayList<>();
		arrayList.add("amit");
		arrayList.add("xyz");
		arrayList.add("xpertit");
		arrayList.add("abc");
		//arrayList.add("amit");
		
		//arrayList.add(0, "pqr");
	
		ArrayList<String> secondList = new ArrayList<>();
		secondList.add("xyz");
		secondList.add("amit1");
		//secondList.add("amit");
		
		//System.out.println(secondList);
		//System.out.println(arrayList);
		
		//arrayList.addAll(secondList);
		//arrayList.addAll(0, secondList);
		//System.out.println(arrayList);
		
		//arrayList.clear();
		//System.out.println(arrayList.contains("amit"));
		
		//System.out.println(arrayList.containsAll(secondList));
		
		//System.out.println(arrayList.indexOf("xyz"));
		//System.out.println(arrayList.isEmpty());
		//arrayList.removeAll(secondList);
		//arrayList.remove("amit");
		//System.out.println(arrayList);
		
		//List<String> subList =  arrayList.subList(1, 4);
		
		//System.out.println(arrayList.retainAll(secondList));
		//arrayList.retainAll(secondList);
		
		for(String li:arrayList) {
			System.out.println(li);
		}
		
		//System.out.println(arrayList);
		
	}

}
