package com;

import java.util.ArrayList;

public class EmployeeData {
	
	public ArrayList<Employee> empData() {
		//
		Employee employee = new Employee();
		employee.setEmpId(1000);
		employee.setEmpName("amit");
		employee.setCity("pune");
		employee.setMobileNumber(101001001);
		
		Employee employee1 = new Employee();
		employee1.setEmpId(1001);
		employee1.setEmpName("xpertit");
		employee1.setCity("mumbai");
		employee1.setMobileNumber(101001031);
		
		
		Employee employee2 = new Employee();
		employee2.setEmpId(1002);
		employee2.setEmpName("amit");
		employee2.setCity("nagpur");
		employee2.setMobileNumber(101001012);
		
		ArrayList<Employee> listOfEmp = new ArrayList<>();
		
		listOfEmp.add(employee);
		listOfEmp.add(employee1);
		listOfEmp.add(employee2);
		
		
		return listOfEmp;
	}

}
