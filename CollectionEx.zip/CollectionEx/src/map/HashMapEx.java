package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashMap = new HashMap<>();
		
		hashMap.put(100, "deepak");
		hashMap.put(101, "ajay");
		hashMap.put(102, "deepak1");
		//hashMap.put(100, "bijay");
		hashMap.put(103, null);
		hashMap.put(null, null);
		hashMap.put(null, "abc");
		
		
//		System.out.println(hashMap.size());
//		System.out.println(hashMap.get(103));
//		
//		for(Entry<Integer, String> map:hashMap.entrySet()) {
//			System.out.println("key: "+map.getKey()+" value: "+map.getValue());
//		}
		
		//System.out.println(hashMap.get(100).equals("deepak"));
		//System.out.println(hashMap.getOrDefault(100, "hello"));
		//System.out.println(hashMap.putIfAbsent(104, "new deepak"));
		//System.out.println(hashMap.toString());
		
		//System.out.println(hashMap.keySet());
		//System.out.println(hashMap.values());
	}

}
