package map;

public class User {
	
	private long adhaarNumber;
	private String userName;
	private String gender;
	private String address;
	private long contactNumber;
	
	public long getAdhaarNumber() {
		return adhaarNumber;
	}
	public void setAdhaarNumber(long adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Override
	public String toString() {
		return "User [adhaarNumber=" + adhaarNumber + ", userName=" + userName + ", gender=" + gender + ", address="
				+ address + ", contactNumber=" + contactNumber + "]";
	}
	
	
	

}
