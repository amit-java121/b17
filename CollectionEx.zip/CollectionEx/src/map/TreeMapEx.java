package map;

import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;

public class TreeMapEx {
	
	public static void main(String[] args) {
		
		TreeMap<String, String> treeMap = new TreeMap<>();
		
		treeMap.put("sanjay", "abc");
		treeMap.put("ajay", "xyz");
		treeMap.put("bijay", "pqr");
		treeMap.put("deepak", "abc");
		treeMap.put("abc", null);
		
//		NavigableMap<String, String> desc = treeMap.descendingMap();
//		System.out.println(desc);
//		
//		for(Entry<String,String> map:treeMap.entrySet()) {
//			System.out.println(map.getKey()+" "+map.getValue());
//		}
		//treeMap.replace("ajay", "abababba");
		//treeMap.replace("ajay", "xyz", "XYZ");
		System.out.println(treeMap.subMap("ajay", "deepak"));
		
	}

}
