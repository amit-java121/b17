package map;

import java.util.Hashtable;

public class HashTableEx {
	
	public static void main(String[] args) {
		
		Hashtable<Integer, String> hashtable = new Hashtable<>();
		
		hashtable.put(100, "abc");
		hashtable.put(101, "abc1");
		hashtable.put(102, "abc2");
		hashtable.put(103,null);
		
		System.out.println(hashtable);
		
	}

}
