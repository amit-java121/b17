package map;

import java.util.HashMap;

public class FetchUserData {
	
	public User getUserDataByAdhaarNumber(long adhaar) {
		UserData userData = new UserData();
		HashMap<Long, User> userMap = userData.createUserData();
		
		User user = userMap.get(adhaar);
		
		return user;
	}
	
	
	public static void main(String[] args) {
		FetchUserData fud = new FetchUserData();
		User user = fud.getUserDataByAdhaarNumber(10000001011l);
		if(user != null) {
			System.out.println(user.toString());
		}else {
			System.out.println("Adhaar number is not valid!!! Please try again:::");
		}
		
		
		
	}

}
