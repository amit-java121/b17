package map;

import java.util.HashMap;

public class UserData {
	
	public HashMap<Long, User> createUserData() {
		
		User user = new User();
		user.setAdhaarNumber(10000001010l);
		user.setAddress("pune");
		user.setContactNumber(10888888888l);
		user.setGender("male");
		user.setUserName("Ajay");
		
		User user2 = new User();
		user2.setAdhaarNumber(10000001011l);
		user2.setAddress("mumbai");
		user2.setContactNumber(10888888888l);
		user2.setGender("female");
		user2.setUserName("Swati");
		
		User user3 = new User();
		user3.setAdhaarNumber(10000001012l);
		user3.setAddress("nagpur");
		user3.setContactNumber(10888888888l);
		user3.setGender("male");
		user3.setUserName("Bijay");
		
		User user4 = new User();
		user4.setAdhaarNumber(10000001013l);
		user4.setAddress("Solapur");
		user4.setContactNumber(10888888888l);
		user4.setGender("male");
		user4.setUserName("Xpertit");
		
		HashMap<Long, User> userMap = new HashMap<Long, User>();
		
		userMap.put(user.getAdhaarNumber(), user);
		userMap.put(user2.getAdhaarNumber(), user2);
		userMap.put(user3.getAdhaarNumber(), user3);
		userMap.put(user4.getAdhaarNumber(), user4);
		
		return userMap;
	}

}
