package set;

import java.util.LinkedHashSet;

public class LinkedHahsSetEx {
	
	public static void main(String[] args) {
		
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		

		linkedHashSet.add("vivek");
		linkedHashSet.add("ajay");
		linkedHashSet.add("bijay");
		linkedHashSet.add("sunil");
		linkedHashSet.add("bijay");
		linkedHashSet.add(null);
		
		System.out.println(linkedHashSet);
		
		
	}

}
