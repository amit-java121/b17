package set;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetEx {
	
	public static void main(String[] args) {
		
		HashSet<String> hashSet = new HashSet<>();
		
		hashSet.add("vivek");
		hashSet.add("ajay");
		hashSet.add("bijay");
		hashSet.add("sunil");
		hashSet.add("bijay");
		hashSet.add(null);
		
//		String name = "bijay";
//		System.out.println(name.hashCode());
//		String name2 = "vivek";
//		System.out.println(name2.hashCode());
//		
//		
//		String name3 = "Vivek";
//		System.out.println(name3.hashCode());
//		
//		System.out.println(hashSet);
		
		
		Iterator<String> itr = hashSet.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		for(String set:hashSet) {
			System.out.println(set);
		}
		
	}

}
