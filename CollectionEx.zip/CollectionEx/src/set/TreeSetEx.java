package set;

import java.util.NavigableSet;
import java.util.TreeSet;

public class TreeSetEx {
	
	public static void main(String[] args) {
		
		TreeSet<String> treeSet = new TreeSet<>();
		treeSet.add("vivek");
		treeSet.add("ajay");
		treeSet.add("vijay");
		treeSet.add("sunil");
		treeSet.add("sanjay");
		//treeSet.add(null);
		NavigableSet<String> descTreeSet = treeSet.descendingSet();
		
		//System.out.println(treeSet.ceiling("bijay"));
		//System.out.println(treeSet.floor("amit"));
		
		//System.out.println(treeSet.higher("amit"));
		System.out.println(treeSet.headSet("amit"));
		//System.out.println(descTreeSet);
		
	}

}
