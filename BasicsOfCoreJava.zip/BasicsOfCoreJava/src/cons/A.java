package cons;

public class A {
	
	int age;
	String name;
	
	public A() {
		System.out.println("default const called::");
	}
//	
	public A(int age1,String name1) {
		System.out.println("param called::");
		age = age1;
		name = name1;
		
	}
	
	
	public void test() {
		
		System.out.println(age);
		System.out.println(name);
	}
	
	public static void main(String[] args) {
		A a = new A(25,"Ajay");
		a.test();
		//A aa = new A();

	}

}
