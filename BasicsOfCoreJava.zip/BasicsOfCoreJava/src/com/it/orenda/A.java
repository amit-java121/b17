package com.it.orenda;

import com.it.hi.B;

public class A {
	
	public void m1() {
		
		B b = new B();
		
	}

}
