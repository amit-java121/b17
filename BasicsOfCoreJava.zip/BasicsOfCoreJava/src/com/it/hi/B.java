package com.it.hi;

public class B {

}
