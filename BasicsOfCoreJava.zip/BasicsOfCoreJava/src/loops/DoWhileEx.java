package loops;

public class DoWhileEx {
	
	public static void main(String[] args) {
//		boolean flag =false;
//
//		while(flag) {
//			System.out.println("normal while");
//		}
		
		
		int i=0;
		do {
			
			//logic here
			System.out.println("do executed::");
			i++;
		}while(i<5);
		
		
		
		
	}
	
	

}
