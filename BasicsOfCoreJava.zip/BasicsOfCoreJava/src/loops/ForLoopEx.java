package loops;

public class ForLoopEx {
	
	public static void main(String[] args) {
		
//		case 1:
		
//		for(int a=1; a<=5; a++) {
//			
//			System.out.println("a= "+a);
//			
//			for(int b=1; b<=5; b++) {
//				System.out.println("b= "+b);
//				
//				if(b==2) {
//					System.out.println("our required number found");
//					break;
//				}
//			}
//			
//			
//		}
		
		//case 2:

		aa:
		for(int a=1; a<=5; a++) {
			
			System.out.println("a= "+a);
			
			for(int b=1; b<=5; b++) {
				System.out.println("b= "+b);
				
				if(b==2) {
					System.out.println("our required number found");
					break aa;
				}
			}
			
			
		}
		
	}

}
