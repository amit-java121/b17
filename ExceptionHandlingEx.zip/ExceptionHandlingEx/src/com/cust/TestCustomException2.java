package com.cust;

public class TestCustomException2 {
	
	public static void main(String[] args) {
		String code = "";
		TestCustomException tse = new TestCustomException();
		try {
			String message = tse.verifyUserDetails("xpertit");
			String[] strName= message.split(",");
			code = strName[0];
		 //code = message.substring(0, 3);
			
		} catch (UserNotFoundException e) {
			System.out.println(e.getCode()+" "+e.getDescription());
		}
		
		//remaining process
		if(code.equals("200")) {
			
			System.out.println("inside if ::");
			
		}
		
		
	}

}
