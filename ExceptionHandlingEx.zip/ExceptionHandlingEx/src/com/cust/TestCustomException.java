package com.cust;

public class TestCustomException {
	
	
	public String verifyUserDetails(String username) throws UserNotFoundException {
		String msg = "";
		if(username.equalsIgnoreCase("xpertit")) {
			//user
			msg = "200,User verifued successfully";
			
		}else {
			throw new UserNotFoundException(400, "User not found");
		}
		
		return msg;
	}

}
