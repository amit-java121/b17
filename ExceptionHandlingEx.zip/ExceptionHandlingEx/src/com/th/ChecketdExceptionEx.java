package com.th;

public class ChecketdExceptionEx {
	
	public void getDBConnection() throws ClassNotFoundException {
		
		//we are going get user data from DB
		
		Class.forName("");
		
	}
	
	
	
	public void printData() throws ClassNotFoundException {
		getDBConnection();
	}
	
	public static void main(String[] args) {
		ChecketdExceptionEx ce = new ChecketdExceptionEx();
		try {
			ce.printData();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
