package com.th;

public class ThrowsEx {

	public void test() throws Exception {

		System.out.println("");

	}

	public void test2() {
		try {
			test();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("");

	}

}
