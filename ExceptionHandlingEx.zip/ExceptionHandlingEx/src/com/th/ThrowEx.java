package com.th;

import java.io.IOException;

public class ThrowEx {
	
	public String verifyUserName(String username) throws IOException {
		
		String msg = "";
		if(username.equals("xpert")) {
			msg = "User name is verified";
		}else {
			throw new IOException("User name is not verified!");
		}
		
		return msg;
	}
	
	
	
	public static void main(String[] args) {
		ThrowEx te = new ThrowEx();
		try {
			String msg = te.verifyUserName("xpertit");
			System.out.println(msg);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
