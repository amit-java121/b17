package com;

public class ExceptionEx2 {
	
	public void calculation(int a,int b,String name) {
		
		System.out.println("number 1");
		System.out.println("number 2");
		System.out.println("number 3");
		System.out.println("number 4");
		try {
		
		int c = a/b;
		System.out.println("result::"+c);
		
		if(name.equals("xpertit")) {
			System.out.println("if block executed::");
		}
		
		}catch(ArithmeticException ae) {
			System.out.println("you can not devide by zero, please try with another number::");
		}catch(Exception npe) {
			System.out.println(" name can not be null:::");
		}
		
		System.out.println("number 5");
		
		System.out.println("number 6");
		
	}
	
	public static void main(String[] args) {
		
		ExceptionEx2 ee = new ExceptionEx2();
		ee.calculation(10, 2,null);
	}

}
