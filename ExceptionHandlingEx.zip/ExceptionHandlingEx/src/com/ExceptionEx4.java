package com;

public class ExceptionEx4 {
	
	public void calculation(int a,int b) {
		
		try {
		
		int c = a/b;
		System.out.println("result::"+c);
		
		}finally {
			System.out.println("finally block executed::");
		}
		
	}
	
	public static void main(String[] args) {
		
		ExceptionEx4 ee = new ExceptionEx4();
		ee.calculation(10, 0);
	}

}
