package com;

public class ExceptionEx3 {
	
	public void calculation(int a,int b,String name) {
		
		System.out.println("number 1");
		System.out.println("number 2");
		System.out.println("number 3");
		System.out.println("number 4");
		try {
		
		int c = a/b;
		System.out.println("result::"+c);
		
		try {
			
			if(name.equals("xpertit")) {
				System.out.println("if block executed::");
			}
			
		}catch(NullPointerException npe) {
			System.out.println("name cant be null");
		}
		
		}catch(ArithmeticException ae) {
			System.out.println("you can not devide by zero, please try with another number::");
		}
		
		System.out.println("number 5");
		
		System.out.println("number 6");
		
	}
	
	public static void main(String[] args) {
		
		ExceptionEx3 ee = new ExceptionEx3();
		ee.calculation(10, 0,null);
	}

}
