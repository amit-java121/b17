package com;

public class Test {
	
	public void printData() {
		
		User user = (User)TestUser.getObject("user");
		
		
		User user1 = (User)TestUser.getObject("user");
		user.print();
	}
	
	public static void main(String[] args) {
		Test test =  new Test();
		test.printData();
	}

}
