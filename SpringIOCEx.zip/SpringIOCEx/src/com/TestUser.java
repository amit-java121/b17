package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestUser {
	
	
	public static Object getObject(String objectId) {
		
		Resource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		
		return beanFactory.getBean(objectId);
		
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		
//		Resource resource = new ClassPathResource("applicationContext.xml");
//		BeanFactory beanFactory = new XmlBeanFactory(resource);
//		
//		User userObj = (User)beanFactory.getBean("user");
//		
//		userObj.print();
		
	}

}
