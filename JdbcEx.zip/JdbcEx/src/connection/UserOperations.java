package connection;

import java.util.List;

public class UserOperations {
	
	public void getAllUserData() {
		TestConnection tc = new TestConnection();
		List<User> userList = tc.getUserDataFrmDB();
		
		for(User user:userList) {
			System.out.println(user.toString());
		}
		
		//System.out.println(userList.toString());
		//print
	}

	public void getUSerById() {
		User user = TestConnection.getUserById(2);
		System.out.println(user.toString());
	}
	
	public static void main(String[] args) {
		UserOperations up = new UserOperations();
		//up.getAllUserData();
		up.getUSerById();
	}
}
