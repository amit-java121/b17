package connection;

import java.util.ArrayList;
import java.util.List;

public class UserOperations {
	
	public void getAllUserData() {
		TestConnection tc = new TestConnection();
		List<User> userList = tc.getUserDataFrmDB();
		
		for(User user:userList) {
			System.out.println(user.toString());
		}
		
		//System.out.println(userList.toString());
		//print
	}

	public void getUSerById() {
		User user = TestConnection.getUserById(2);
		System.out.println(user.toString());
	}
	
	
	public void insertUserData() {
		User user = new User();
		user.setUserName("Komal");
		user.setContact(9898981111l);
		user.setGender("female");
		user.setUserEmail("komal@gmail.com");
		user.setUserPass("abc@123");
		
		TestConnection tc = new TestConnection();
		
		tc.inserUserData(user);
		
	}
	
	
	public void insertListOfUser() {
		List<User> listOfUsers = new ArrayList<User>();
		
		User user = new User();
		user.setUserName("Komal");
		user.setContact(9898981111l);
		user.setGender("female");
		user.setUserEmail("komal@gmail.com");
		user.setUserPass("abc@123");
		
		
		User user2 = new User();
		user2.setUserName("Swati");
		user2.setContact(9898981111l);
		user2.setGender("female");
		user2.setUserEmail("swati@gmail.com");
		user2.setUserPass("abc@123");
		
		User user3 = new User();
		user3.setUserName("Neelam");
		user3.setContact(9898981111l);
		user3.setGender("female");
		user3.setUserEmail("neelam@gmail.com");
		user3.setUserPass("abc@123");
		
		
		listOfUsers.add(user);
		listOfUsers.add(user2);
		listOfUsers.add(user3);
		
		
		TestConnection tc = new TestConnection();
		
		tc.inserUserAllUsers(listOfUsers);
		
	}
	
	
	public void deleteUserById(int id) {
		TestConnection.deleteUserById(id);
		
	}
	
	
	
	public static void main(String[] args) {
		UserOperations up = new UserOperations();
		//up.getAllUserData();
		//up.getUSerById();
		//up.insertUserData();
		//up.insertListOfUser();
		up.deleteUserById(6);
	}
}
