package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestConnection {
	
	public static void main(String[] args) {
			String query = "select * from user_tb where user_id=2";
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("step 1");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
				System.out.println("step 2");
				Statement stmt = conn.createStatement();
				System.out.println("step 3");
				ResultSet rs = stmt.executeQuery(query);
				
				while(rs.next()) {
//					System.out.println(rs.getInt("user_id"));
//					System.out.println(rs.getString("user_name"));
//					System.out.println(rs.getString("user_pass"));
//					System.out.println(rs.getString("user_email"));
//					System.out.println(rs.getLong("user_contact"));
//					System.out.println(rs.getString("user_gender"));
					
					
					System.out.println(rs.getInt(1));
					System.out.println(rs.getString(2));
					System.out.println(rs.getString(3));
					System.out.println(rs.getString(4));
					System.out.println(rs.getLong(5));
					System.out.println(rs.getString(6));
				}
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}

}
