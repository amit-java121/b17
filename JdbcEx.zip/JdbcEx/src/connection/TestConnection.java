package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TestConnection {
	
	public static void main(String[] args) {
			String query = "select * from user_tb where user_id=2";
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("step 1");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
				System.out.println("step 2");
				Statement stmt = conn.createStatement();
				System.out.println("step 3");
				ResultSet rs = stmt.executeQuery(query);
				
				while(rs.next()) {
//					System.out.println(rs.getInt("user_id"));
//					System.out.println(rs.getString("user_name"));
//					System.out.println(rs.getString("user_pass"));
//					System.out.println(rs.getString("user_email"));
//					System.out.println(rs.getLong("user_contact"));
//					System.out.println(rs.getString("user_gender"));
					
					
					System.out.println(rs.getInt(1));
					System.out.println(rs.getString(2));
					System.out.println(rs.getString(3));
					System.out.println(rs.getString(4));
					System.out.println(rs.getLong(5));
					System.out.println(rs.getString(6));
				}
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}
	
	
	public List<User> getUserDataFrmDB() {
		
		List<User> list = new ArrayList<>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
			System.out.println("step 2");
			Statement stmt = conn.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user_tb");
			
			while(rs.next()) {
				User user = new User();
				user.setUserID(rs.getInt("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setUserEmail(rs.getString("user_email"));
				user.setGender(rs.getString("user_gender"));
				user.setContact(rs.getLong("user_contact"));
				
				list.add(user);
				
			}
			
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public static User getUserById(int userId) {
		User user = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
			System.out.println("step 2");
			Statement stmt = conn.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user_tb where user_id="+userId);
			 user = new User();
			while(rs.next()) {
				user.setUserID(rs.getInt("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setUserEmail(rs.getString("user_email"));
				user.setGender(rs.getString("user_gender"));
				user.setContact(rs.getLong("user_contact"));
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}
	
	public void inserUserData(User user) {
		
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
			System.out.println("step 2");
			Statement stmt = conn.createStatement();
			System.out.println("step 3");
			int i = stmt.executeUpdate("insert into user_tb (user_name,user_pass,user_email,user_contact,user_gender) values('"+user.getUserName()+"','"+user.getUserPass()+"','"+user.getUserEmail()+"',"+user.getContact()+",'"+user.getGender()+"')");
			System.out.println("i "+i);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void inserUserAllUsers(List<User> listOfUsers) {
		
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
			System.out.println("step 2");
			Statement stmt = conn.createStatement();
			System.out.println("step 3");
			
//			for(int i=0; i<listOfUsers.size(); i++) {
//				User user = listOfUsers.get(i);
//			}
			for(User user:listOfUsers) {
				int i = stmt.executeUpdate("insert into user_tb (user_name,user_pass,user_email,user_contact,user_gender) values('"+user.getUserName()+"','"+user.getUserPass()+"','"+user.getUserEmail()+"',"+user.getContact()+",'"+user.getGender()+"')");
				System.out.println("i "+i);
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}


	public static void deleteUserById(int id) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root", "root");
			System.out.println("step 2");
			Statement stmt = conn.createStatement();
			System.out.println("step 3");
			
			stmt.executeUpdate("delete from user_tb where user_id="+id);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
