package conditionalstmt;

public class UserLogin {
	
	public boolean verifyUserCredentials(String username,String password) {
		
		System.out.println("welcome to the site:::");
		if(username.equalsIgnoreCase("ajay123") && password.equalsIgnoreCase("ajay")) {
			return true;
			//System.out.println("you successfully logged in:::");
		}else {
			return false;
			//System.out.println("your user name and password is incorrect! please try again!!");
		}
		
	}


}
