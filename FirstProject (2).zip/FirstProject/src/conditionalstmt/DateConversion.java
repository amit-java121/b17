package conditionalstmt;

public class DateConversion {
	
	public void dateFormat(String monthName) {
		System.out.println("month name: "+monthName);
		
	}
	
	
	public static void main(String[] args) {
		DateConversion dc = new DateConversion();
		//10-FEB-2020
		//10-02-2020
		String date = "10-FEB-2020";
		String month = extractMonthName(date);
		
		dc.dateFormat(month);
	}
	
	
	public static String extractMonthName(String date) {
		
		String monthName= date.substring(3, 6);
	 return monthName;
	}

}
