package conditionalstmt;

public class ElseIfLadderEx {
	
	public void testIfElse(int marks) {
		
		System.out.println("inside testIfElse");
		
		if(marks == 30) {
			System.out.println("You are passed");
		}else if(marks == 60){
			System.out.println("You are passwed with first devision::");
		}else if(marks == 75 ) {
			System.out.println("You are passwed with first Good devison::");
		}else {
			System.out.println("you are failed::");
		}
		
		
	}
	
	public static void main(String[] args) {
		ElseIfLadderEx ee = new ElseIfLadderEx();
		ee.testIfElse(30);
	}

}
