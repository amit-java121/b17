package conditionalstmt;

public class TestSwitchStmt {

	public void test(int age) {

		switch (age) {
		case 30:
			System.out.println("age is " + age);
			break;
		case 40:
			System.out.println("age is " + age);
			break;
		case 50:
			System.out.println("age is "+age);
			break;
		case 60:
			System.out.println("age is "+age);
			break;
		default:
			System.out.println("default case executed:: ");
		}

	}
	
	public static void main(String[] args) {
		TestSwitchStmt ts = new TestSwitchStmt();
		ts.test(60);
	}

}
