package datatype;

public class DataTypesEx {
	
	boolean flag;
	char c ='A';
	byte b;
	short s;
	int a;
	float f = 0010.100f;
	long l = 17177171711l;
	double d = 101001.91919919199191d;
	
	
	public void print() {
		System.out.println(flag);
		System.out.println(c);
		System.out.println(b);
		System.out.println(s);
		System.out.println(f);
		System.out.println(l); 
	}
	
	
	
	public static void main(String[] args) {
		DataTypesEx dt = new DataTypesEx();
		dt.print();
	}
	

}
