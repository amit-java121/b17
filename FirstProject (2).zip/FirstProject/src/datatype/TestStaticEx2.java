package datatype;

public class TestStaticEx2 {
	
	public static void main(String[] args) {
		
		TestStaticEx ts = new TestStaticEx();
		System.out.println(ts.age);
		System.out.println(ts.mobileNo);
		
		System.out.println(TestStaticEx.mobileNo);
		
		
		
	}

}
