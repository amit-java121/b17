package it;
import com.Duster;

public class Test {
	int a=10;
	
	public static void main(String[] args) {
//		Duster dd = new Duster();
//		dd.color();
		
		Calculation c = new Calculation();
		int addition =c.add(100,60);
		System.out.println("test class:"+addition);
		
	}
	
	

}
