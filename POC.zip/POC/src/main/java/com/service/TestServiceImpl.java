package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Customer;
import com.repositry.TestRepository;
@Service
public class TestServiceImpl implements TestService{

	@Autowired
	TestRepository testRepository;
	
	@Override
	public void saveCustomerItems(Customer customer) {
		
		testRepository.save(customer);
		
	}

}
