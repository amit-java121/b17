package com.service;

import com.model.Customer;

public interface TestService {

	void saveCustomerItems(Customer customer);

}
