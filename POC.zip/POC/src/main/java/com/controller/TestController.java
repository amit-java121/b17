package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Customer;
import com.service.TestService;

@RestController
public class TestController {
	
	@Autowired
	TestService testService;
	
	@PostMapping("/save-item")
	public void saveCustomerItems(@RequestBody Customer customer) {
		System.out.println(customer.toString());
		testService.saveCustomerItems(customer);
		
	}

}
