package conditionalstmt;

import java.util.Scanner;

public class DateConversion {
	
	public String dateFormat(String monthName) {
		//System.out.println("month name: "+monthName);
		
		String monthNumber = "";
		
		switch (monthName) {
		case "JAN":
			monthNumber ="01";
			break;
		case "FEB":
			monthNumber ="02";
			break;

		case "MAR":
			monthNumber ="03";
			break;
		case "APR":
			monthNumber ="04";
			break;
		case "MAY":
			monthNumber ="05";
			break;
		case "JUN":
			monthNumber ="06";
			break;
		case "JUL":
			monthNumber ="07";
			break;
		case "AUG":
			monthNumber ="08";
			break;
		case "SEP":
			monthNumber ="09";
			break;

		default:
			break;
		}
		
		return monthNumber;
		
	}
	
	
	public static void main(String[] args) {
		DateConversion dc = new DateConversion();
		//10-FEB-2020
		//10-02-2020
		//String date = "10-SEP-2020";
		
		Scanner sc = new Scanner(System.in);
		String date = sc.nextLine();
		
		String month = extractMonthName(date);
		
		String monthNumber = dc.dateFormat(month);
		
		String formattedDate = date.replace(month, monthNumber);
		
		System.out.println("converted date:: "+formattedDate);
		
	}
	
	
	public static String extractMonthName(String date) {
		
		String monthName= date.substring(3, 6);
	 return monthName;
	}

}
