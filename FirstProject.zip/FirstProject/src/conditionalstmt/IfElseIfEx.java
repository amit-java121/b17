package conditionalstmt;

public class IfElseIfEx {
	
	
	public void testIfElse(int age) {
		
		System.out.println("inside testIfElse");
		
		if(age >= 25) {
			System.out.println("if executed:::");
		}else {
			System.out.println("else exeucted:::");
		}
		
		System.out.println("after testIfElse");
		
	}
	
	public static void main(String[] args) {
		IfElseIfEx ief = new IfElseIfEx();
		ief.testIfElse(20);
	}

}
