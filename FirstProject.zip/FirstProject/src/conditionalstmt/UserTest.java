package conditionalstmt;

public class UserTest {
	
	public static void main(String[] args) {
		UserLogin ul = new UserLogin();
		boolean flag= ul.verifyUserCredentials("ajay1234", "ajay1");
		
		if(flag) {
			System.out.println("you successfully logged in:::");
		}else {
			System.out.println("your user name and password is incorrect! please try again!!");
		}
	}

}
