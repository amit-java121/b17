package methods;

public class A {
	
	
	public int add(int a, int b) {

		int sum = a + b;

		return sum;
	}

	public void test() {
		int sum = add(50, 50);
		int multyply = sum * 100;

		System.out.println(multyply);
	}

}
