package methods;

public class Test {
	
	public static void main(String[] args) {
		
    	A a = new A();
//		int sum1 =a.add(10,20);
//		
//		System.out.println("Test::: "+sum1);
		
    	a.test();
		
	}

}
