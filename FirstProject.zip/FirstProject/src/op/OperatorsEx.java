package op;

public class OperatorsEx {
	
	public static void main(String[] args) {
		
		//int a = 10;
//		System.out.println(a);//10
//		System.out.println(++a);//11
//		System.out.println(a);//11
//		System.out.println(a++);//11//10
//		System.out.println(a);//10//12
		
		//a *= 20;
	
		
		//System.out.println(a==b);
		
//		if(a != b) {
//			System.out.println("code :::");
//		}
		
//		if(a != b) {
//		
//			System.out.println("inside if:::");
//		}
		int a = 10;
		int b =20;
		int c = 30;
		
//		if(a < b | b < c) {
//			System.out.println("if block executed:::");
//		}
		
		System.out.println( ( a < b ) ? 50:100);
		
	}

}
