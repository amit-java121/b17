package it;

public class Calculation {
	
	public int add(int a,int b) {
//		int a=10;
//		int b = 20;
//		
		int sum = a+b;
		
		return sum;
	}

}
