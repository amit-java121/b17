package com;

import it.Calculation;
import it.Test;

public class Duster {
	
	int height =10;
	int width = 10;
	int length = 50;
	
	public void work() {
		
		System.out.println("Board cleANING::::");
		
	}
	
   public void color() {
		
		System.out.println("green:::::::::");
		
	}
   
   public static void main(String[] args) {

	 Calculation c = new Calculation();
	 //int sum = c.add(50, 50);
	 System.out.println(c.add(50, 50));
  }
	

}
