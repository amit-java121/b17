package datatype;

public class VariablesEx {
	
	int a =100;
	int bb =200;
	
	static int sum = 1000;
	
	public void test() {
		 int b =200+a+sum;
	}
	
	public void m1() {
		
		int sum1 = bb+a+sum;
		
	}
	
	
	public static void main(String[] args) {
		System.out.println(sum);
		
		VariablesEx ve = new VariablesEx();
		System.out.println(ve.bb);
	
	}
	
	

}
