package datatype;

public class TestStaticEx {
	
	int age =25;
	static int mobileNo = 10100100;
	static int A;
	
	
	public void m1() {
		//System.out.println(age);
		//System.out.println(mobileNo);
		mobileNo = 181881;
		 A ='B';
	}
	
	public static void m2() {
		//System.out.println(mobileNo);
		//System.out.println(age);
	}
	

	public static void main(String[] args) {
		TestStaticEx te = new TestStaticEx();
		te.m1();
	}
}
