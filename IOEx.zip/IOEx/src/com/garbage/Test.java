package com.garbage;

public class Test {
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("finialize called");
	}
	
	
	public static void main(String[] args) {
		Test test = new Test();
		Test test1 = new Test();
		Test test2 = new Test();
		
		test1 = null;
		test2 = null;
		//
		
		System.gc();
		
	}

}
