package com;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadWriteUsingBuffer {
	
	public void writeIntoFile() throws IOException {
		String str ="hello hello ";
		File file  = new File("C:\\Users\\Amit\\Desktop\\Test.txt");
		FileWriter fw = new FileWriter(file,true);
		
		fw.write("\n"+str);
		fw.close();
		
	}
	
	public void readFrmFile() throws IOException {
		File file = new File("C:\\Users\\Amit\\Desktop\\Test.txt");
		FileReader fr = new FileReader(file);
		int i = 0;
		while ((i = fr.read()) != -1) {
			System.out.print((char)i);
		}
		fr.close();
		
	}
	
	
	
	public static void main(String[] args) {
		ReadWriteUsingBuffer rwub = new ReadWriteUsingBuffer();
		try {
			rwub.readFrmFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
