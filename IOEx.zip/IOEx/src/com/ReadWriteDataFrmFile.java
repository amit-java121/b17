package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ReadWriteDataFrmFile {
	
	public void writeIntoFile(String str) throws Exception {
		
		File file  = new File("C:\\Users\\Amit\\Desktop\\Test.txt");
		FileOutputStream fos = new FileOutputStream(file);
		
		fos.write(str.getBytes());;
		//fos.close();
	}
	
	public void readDataFromFile() throws Exception  {
		File file  = new File("C:\\Users\\Amit\\Desktop\\Test.txt");
		FileInputStream fis = new FileInputStream(file);
		int i=0;
		
		while((i=fis.read()) != -1) {
			System.out.print((char)i);
		}
		
	}
	
	public static void main(String[] args) {
		ReadWriteDataFrmFile rwdf = new ReadWriteDataFrmFile();
		String str = "welcome to the xpert it";
		try {
			//rwdf.writeIntoFile(str);
			rwdf.readDataFromFile();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
