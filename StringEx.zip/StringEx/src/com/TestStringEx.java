package com;

public class TestStringEx {
	
	public static void main(String[] args) {
		
		String str = " Hello";
		String str1 = "Hello";
		
		//System.out.println(str.charAt(2));
		
		//System.out.println(str.compareTo(str1));
	
		
		//System.out.println(str.concat(str1));
		
		//System.out.println(str.contains("ll"));
		
		//System.out.println(str.contentEquals("ll"));
		
		//System.out.println(str.equalsIgnoreCase(str1));
		//System.out.println(str.equals(str1));
		//System.out.println(str.length());
		
		//System.out.println(str.indexOf("o"));
//		System.out.println(str.isEmpty());
//		
//		String[] strArray = str.split("#");
//		for(int i=0;i<strArray.length; i++) {
//			System.out.println(strArray[i]);
//		}
//		
		//System.out.println(str.substring(1, 3));
		//System.out.println(str.replace("hello", "hi"));
		//System.out.println(str.toUpperCase());
		//System.out.println(str.toLowerCase());
		
		if(str.trim().equals(str1)) {
			System.out.println("both string are equal");
		}
		
		System.out.println(str.isEmpty());
		
	}

}
