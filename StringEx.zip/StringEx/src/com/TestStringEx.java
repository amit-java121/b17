package com;

public class TestStringEx {
	
	public static void main(String[] args) {
		
		String str = "hello";
		String str1 = "Hello";
		
		//System.out.println(str.charAt(2));
		
		//System.out.println(str.compareTo(str1));
	
		
		//System.out.println(str.concat(str1));
		
		//System.out.println(str.contains("ll"));
		
		//System.out.println(str.contentEquals("ll"));
		
		//System.out.println(str.equalsIgnoreCase(str1));
		//System.out.println(str.equals(str1));
		System.out.println(str.length());
		
	}

}
