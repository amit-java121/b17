package com;

public class StringEx {
	
	int a =10;
	public static void main(String[] args) {
	
//		String str = "hello";
//		str.concat("xpertit");
//		
//		System.out.println(str);
//		
//		
//		String str1 = "hello";
//		String str2 = str1.concat("xpertit");
//		System.out.println(str2);
		
		
		String str4 = new String("hello");
		String str = "hello";
		
		String str1 = "hello";
		
		String str5 = new String("hello");
		
//		System.out.println(str4 == str);//false
//		System.out.println(str4.equals(str));//false
//		
//		System.out.println(str1 == str);//true
//		
//		System.out.println(str1.equals(str));//true
		
		System.out.println(str4 == str5);//false
		System.out.println(str4.equals(str5));//true
		
		
		
	}
	

}
