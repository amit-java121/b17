package com;

public class StringbuilderEx {
	
	public static void main(String[] args) {
		
		StringBuilder sbb = new StringBuilder("hello aaaaaaaaaaaaaaaaaaaaaaaaaaa");
		
//		sbb.append("abc");
//		
//		
//		sbb.setCharAt(2, 'A');
//		
//		System.out.println(sbb);
		sbb.ensureCapacity(100);
		System.out.println(sbb.capacity());
		
	}

}
