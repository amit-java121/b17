package com;

public class StringBufferEx {

	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("hello");
		
		//sb.append("abc");
		
		//System.out.println(sb);
		
		//System.out.println(sb.capacity());
		//System.out.println(sb.insert(2, "AB"));
		//System.out.println(sb);
		
		System.out.println(sb.reverse());
		
	}
	
}
