package com;

public class Customer extends Payment{

	private static final long serialVersionUID = 7432242066059017718L;
	private int customerId;
	private String customerName;
	
	public Customer(int id, long cardNumber, int cvv, String customerName, int customerId, String customerName2) {
		super(id, cardNumber, cvv, customerName);
		this.customerId = customerId;
		this.customerName = customerName2;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	

}
