package com;

import java.io.Serializable;

public class Payment implements Serializable{
	
	private static final long serialVersionUID = 1849824768757927209L;
	
	private int id;
	private long cardNumber;
	private transient int cvv;
	private static String customerName;
	
	
	public Payment(int id, long cardNumber, int cvv, String customerName) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.customerName = customerName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	

}
