package com;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class UserDataSerilization {
	
	public static void main(String[] args) {
		//Payment payment = new Payment(10001,1818818818818l,1234,"Ajay");
		Customer customer = new Customer(10101, 1717717771, 1234, "Ajay", 100, "Bijay");
		try {
			
			File file =  new File("C:\\Users\\Amit\\Desktop\\test.txt");
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(customer);
			oos.close();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
