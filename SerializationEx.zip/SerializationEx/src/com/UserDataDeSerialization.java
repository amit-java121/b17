package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class UserDataDeSerialization {
	
	public static void main(String[] args) {
		

		try {
			
			File file =  new File("C:\\Users\\Amit\\Desktop\\test.txt");
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			Customer object = (Customer)ois.readObject();
		
			ois.close();
			
			System.out.println(object.getCustomerName());
			System.out.println(object.getCardNumber());
			System.out.println(object.getCvv());
			System.out.println(object.getId());
			System.out.println(object.getCustomerId());
			System.out.println(object.getCustomerName());
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
