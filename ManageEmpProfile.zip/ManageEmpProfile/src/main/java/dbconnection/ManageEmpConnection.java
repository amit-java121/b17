package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Employee;

public class ManageEmpConnection {
	
	public String getEmpLoginDetails(String userName) {
		String empPass = "";
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root","root");
		
		PreparedStatement pstmt = con.prepareStatement("select emp_pass from employee_details where emp_email=?");
		
		pstmt.setString(1, userName);
		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			 empPass = rs.getString("emp_pass");
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return empPass;
		
	}

	public String saveEmpData(Employee emp) {
		String msg = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root","root");
			
		  PreparedStatement pstmt = con.prepareStatement("insert into employee_details(emp_name,emp_email,emp_pass,gender,country) values(?,?,?,?,?)");
			
			pstmt.setString(1, emp.getEmpName());
			pstmt.setString(2, emp.getEmpEmail());
			pstmt.setString(3, emp.getEmpPass());
			pstmt.setString(4, emp.getGender());
			pstmt.setString(5, emp.getCountry());
			
			
			int i = pstmt.executeUpdate();
			if(i > 0) {
				msg="success";
			}
			
			}catch(SQLIntegrityConstraintViolationException se) {
				msg="duplicate";
				
				se.printStackTrace();
			}catch(Exception e) {
				msg ="networkissue";
				e.printStackTrace();
			}
			
		return msg;
	}

	public List<Employee> getAllEmpDataFromDB() {

		List<Employee> listOfEmployee = new ArrayList<>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root","root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employee_details");
			
			while(rs.next()) {
				Employee employee = new Employee();
				employee.setEmpId(rs.getInt("emp_id"));
				employee.setEmpName(rs.getString("emp_name"));
				employee.setEmpEmail(rs.getString("emp_email"));
				employee.setGender(rs.getString("gender"));
				employee.setCountry(rs.getString("country"));
				
				listOfEmployee.add(employee);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return listOfEmployee;
		
	}

}
