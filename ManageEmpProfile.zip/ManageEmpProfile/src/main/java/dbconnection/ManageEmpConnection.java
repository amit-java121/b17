package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import model.Employee;

public class ManageEmpConnection {
	
	public String getEmpLoginDetails(String userName) {
		String empPass = "";
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root","root");
		
		PreparedStatement pstmt = con.prepareStatement("select emp_pass from employee_details where emp_email=?");
		
		pstmt.setString(1, userName);
		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			 empPass = rs.getString("emp_pass");
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return empPass;
		
	}

	public String saveEmpData(Employee emp) {
		String msg = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b17","root","root");
			
		  PreparedStatement pstmt = con.prepareStatement("insert into employee_details(emp_name,emp_email,emp_pass,gender,country) values(?,?,?,?,?)");
			
			pstmt.setString(1, emp.getEmpName());
			pstmt.setString(2, emp.getEmpEmail());
			pstmt.setString(3, emp.getEmpPass());
			pstmt.setString(4, emp.getGender());
			pstmt.setString(5, emp.getCountry());
			
			
			int i = pstmt.executeUpdate();
			if(i > 0) {
				msg="success";
			}
			
			}catch(SQLIntegrityConstraintViolationException se) {
				msg="duplicate";
				
				se.printStackTrace();
			}catch(Exception e) {
				msg ="networkissue";
				e.printStackTrace();
			}
			
		return msg;
	}

}
