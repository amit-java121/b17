package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employee;
import service.ManagerEmpService;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ManagerEmpService managerEmpService = new ManagerEmpService();
		String link= request.getParameter("status");
		System.out.println("value::: "+link);
		if(null != link && link.equalsIgnoreCase("update")) {
			String empId =request.getParameter("empId");
			//int emp_id= Integer.valueOf(empId);
			
			
			Employee employee = managerEmpService.editEmpDatails(Integer.valueOf(empId));
			
			request.setAttribute("emp", employee);
			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			 rd.forward(request, response);
		}else {
			
			
			
			
			Employee employee = new Employee();
			employee.setEmpName(request.getParameter("empName"));
			employee.setEmpEmail(request.getParameter("empEmail"));
			employee.setGender(request.getParameter("gender"));
			employee.setCountry(request.getParameter("country"));
			employee.setEmpId(Integer.valueOf(request.getParameter("empId")));
			
			boolean flag = managerEmpService.update(employee);
			
			if(flag) {
				List<Employee> listOfEmployee = managerEmpService.getAllEmployeeDetails();
				System.out.println(listOfEmployee.toString());
				request.setAttribute("listEmp", listOfEmployee);
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}else {
				
				request.setAttribute("message", "Employee record could not updated. please try again");
				RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
				rd.forward(request, response);
			}
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
