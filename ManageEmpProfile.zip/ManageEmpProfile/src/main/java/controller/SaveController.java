package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employee;
import service.ManagerEmpService;

/**
 * Servlet implementation class SaveController
 */
@WebServlet("/SaveController")
public class SaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String empName = request.getParameter("empName");
		String password = request.getParameter("password");
		String empEmail = request.getParameter("empEmail");
		String gender = request.getParameter("gender");
		String country = request.getParameter("country");
		
		System.out.println(empName+" "+password+" "+empEmail+" "+gender+" "+country);
		Employee emp = new Employee();
		//emp.setEmpId(0)
		emp.setEmpName(empName);
		emp.setEmpPass(password);
		emp.setEmpEmail(empEmail);
		emp.setCountry(country);
		emp.setGender(gender);
		
		ManagerEmpService mes = new ManagerEmpService();
		mes.saveEmpDetails(emp);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
