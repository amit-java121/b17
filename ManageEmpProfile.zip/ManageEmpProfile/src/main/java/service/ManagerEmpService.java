package service;

import dbconnection.ManageEmpConnection;

public class ManagerEmpService {
	
	public boolean verifyEmpCredentials(String username,String password) {
		
		System.out.println("we are in service");
		
		ManageEmpConnection meConnection = new ManageEmpConnection();
		String empPass = meConnection.getEmpLoginDetails(username);
		
		if(!password.isEmpty()&& !empPass.isEmpty() && password.equalsIgnoreCase(empPass)) {
			return true;
		}else {
			return false;
		}
		
		
	}
	
	

}
