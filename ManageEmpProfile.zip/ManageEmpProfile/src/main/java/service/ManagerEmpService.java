package service;

import java.util.List;

import dbconnection.ManageEmpConnection;
import model.Employee;

public class ManagerEmpService {
	
	public boolean verifyEmpCredentials(String username,String password) {
		
		System.out.println("we are in service");
		
		ManageEmpConnection meConnection = new ManageEmpConnection();
		String empPass = meConnection.getEmpLoginDetails(username);
		
		if(!password.isEmpty()&& !empPass.isEmpty() && password.equalsIgnoreCase(empPass)) {
			return true;
		}else {
			return false;
		}
		
		
	}

	public String saveEmpDetails(Employee emp) {
		System.out.println("service::: "+emp.toString());
		ManageEmpConnection meConnection = new ManageEmpConnection();
		//boolean flag = meConnection.saveEmpData(emp);
		
		return meConnection.saveEmpData(emp);
		
	}

	public List<Employee> getAllEmployeeDetails() {
		ManageEmpConnection meConnection = new ManageEmpConnection();
		
		return meConnection.getAllEmpDataFromDB();
		
	}
	
	

}
