package encapsulation;

public class TestEmployee {
	
	public Employee setEmpData() {
		Employee employee = new Employee();
		employee.setEmpId(1000);
		employee.setEmpName("xpert it");
		employee.setEmpAddress("pune");
		
		return employee;
	}
	
	public static void main(String[] args) {
		
		TestEmployee testEmployee = new TestEmployee();
		Employee emp = testEmployee.setEmpData();
		//System.out.println(emp.getEmpId());
		
		System.out.println(emp.toString());
		
		
	}

}
