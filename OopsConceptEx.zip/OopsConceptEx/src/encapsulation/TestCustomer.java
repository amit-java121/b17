package encapsulation;

public class TestCustomer {
	
	
	public Customer setDataIntoCustomer() {
		Customer customer = new Customer(100,"Ajay","pune");
		return customer;
	}
	
	public static void main(String[] args) {
		
		
		TestCustomer tc = new TestCustomer();
		Customer custo = tc.setDataIntoCustomer();
		
		
		System.out.println(custo.getCustomerId());
		System.out.println(custo.getCustomerName());
		System.out.println(custo.getCustomerAddress());
		
	
		
	}

}
