package poly;

public class Test {
	
	public void add(int a,long b) {
		System.out.println(" first add called");
	}
	
	public void add(long a,int b) {
		System.out.println(" second add called");
	}
	
	public static void main(String[] args) {
		Test t = new Test();
		//t.add(10, 10);
		
	}

}
