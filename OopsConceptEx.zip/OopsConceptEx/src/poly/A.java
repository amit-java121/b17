package poly;

public class A {
	
	int aa =20;
	
	public void m1(int a,int b) {
		System.out.println(" m1 called form class A");
	}

}
