package poly;

public class B extends A{
	
	int aa =20;
	
	public void m1(int a,int b) {
		System.out.println(" m1 called form class B");
	}
	
	
	public static void main(String[] args) {
		B b = new B();
		
		
	}

}
