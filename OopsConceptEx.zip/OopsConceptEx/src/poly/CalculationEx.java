package poly;

public class CalculationEx {
	
	public int add(int a,int b) {
		
		int sum = a+b;
		
		return sum;
	}
	
	public int add(int a,int b,int c) {
		
		int sum = a+b+c;
		
		return sum;
	}	
	
	
	public static void main(String[] args) {
		CalculationEx ce = new CalculationEx();
		ce.add(10, 10);
		ce.add(10, 10,10);
	}

}
