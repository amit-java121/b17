package abst;

public class AI {

}
