package sup;

public class B extends A{
	
	int bb = 20;
	
	public void m1() {
		super.m1();
		m3();
		System.out.println("m1 called from class B");
	}
	
	public B() {
		super(10);
		System.out.println("const B");
	}
	
	
	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		b.m1();
	}

}
