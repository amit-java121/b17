package sup;

public class A {
	
	int aa = 10;
	
	public void m1() {
		System.out.println("m1 called from class A");
	}
	
	public void m3() {
		System.out.println("m3 called from class A");
	}
	
	public A() {
		System.out.println("const called:: A");
	}
	
	public A(int a) {
		System.out.println("const called:: A"+a);
	}

}
