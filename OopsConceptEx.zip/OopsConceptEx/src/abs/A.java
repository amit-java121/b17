package abs;

public abstract class A {
	
	public abstract void m1();
	
	
	public void test() {
		
	}
	
}
