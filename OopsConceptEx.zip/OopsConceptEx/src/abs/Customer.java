package abs;

public class Customer extends CommonLogic{

	@Override
	public boolean verifyUserCredentials(String userId) {
		
		if(userId.equals("test@123")) {
		 return true;	
		}
		return false;
	}
	
	
	
	
	public static void main(String[] args) {
		Customer c = new Customer();
		boolean flag = c.verifyUserCredentials("test@123");
		if(flag) {
			System.out.println("Customer has been verifiead:::");
		}
		
		String msg = c.logUserActivities("test@123");
		System.out.println(msg);
	}
	
	

}
