package abs;

public class Test extends A{

	@Override
	public void m1() {
		System.out.println("m1 called form Test");
		
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		test.m1();
		test.test();
	}

}
