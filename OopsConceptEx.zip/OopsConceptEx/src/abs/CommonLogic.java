package abs;

public abstract class CommonLogic {
	
	public abstract boolean verifyUserCredentials(String userId);
	
	public String logUserActivities(String userId) {
		
		System.out.println("logged user activities:::"+userId);
		
		
		return "logged user activities successfully";
	}

}
