package interf;

public class Test {
	
	public static void main(String[] args) {
		Car car = new Car();
		System.out.println(car.engine());
		
		Bus bus = new Bus();
		System.out.println(bus.color());
	}

}
