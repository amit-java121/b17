package interf;

public class Bus implements IVehicle{

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 6;
	}

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 2500;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "Gray";
	}

}
