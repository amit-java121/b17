package interf;

public interface IVehicle {
	
	 public int weels();
	 public int engine();
	 public String color();

}
