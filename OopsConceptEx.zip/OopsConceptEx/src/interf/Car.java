package interf;

public class Car implements IVehicle{

	@Override
	public int weels() {

		System.out.println("car weels 4");
		return 4;
	}

	@Override
	public int engine() {
		
		return 1200;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "blue";
	}


}
