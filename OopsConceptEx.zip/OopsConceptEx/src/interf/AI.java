package interf;

public interface AI {
	void m1();
	public abstract void m2();


}
