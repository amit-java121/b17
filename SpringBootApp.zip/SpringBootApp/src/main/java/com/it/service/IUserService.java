package com.it.service;

public interface IUserService {

	boolean verifyUserCredentials(String username, String password);

}
