package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.it.dao.UserRepository;
import com.it.exception.UserNotFountException;
import com.it.model.User;
@Service
public class UserServiceImpl implements IUserService{
	
	@Autowired
	UserRepository userRepository;

	@Override
	public boolean verifyUserCredentials(String username, String password) {
		
		User user = userRepository.getByUserEmail(username);
		
		if(user!= null && user.getUserPass().equals(password)) {
			return true;
		}
		
		System.out.println(user.toString());
		
		return false;
		
		
	}

	@Override
	public void saveUserDetails(User user) {
		
		userRepository.save(user);
	}

	@Override
	public List<User> getAllUserData() {

		List<User> listOfUsers = userRepository.findAll();
		
		return listOfUsers;
	}

	@Override
	public void deleteUserById(int userid) throws UserNotFountException{
		userRepository.deleteById(userid);	
	
	}
	
	

}
