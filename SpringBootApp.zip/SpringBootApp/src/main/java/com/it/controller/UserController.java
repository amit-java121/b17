package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.it.exception.UserNotFountException;
import com.it.model.User;
import com.it.service.IUserService;

@RestController
public class UserController {
	
	@Autowired
	IUserService userService;
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username,@RequestParam("password") String password) {
		System.out.println("login method called::"+username+""+password);
		boolean flag = userService.verifyUserCredentials(username,password);
		if(flag) {
			return "hello! you are logged in thanl you";
		}
		
		return "Your user name and password is incorrect please try again!!";
	}
	
	@PostMapping("/save")
	public void saveUserDetails(@RequestBody User user) {
		System.out.println(user.toString());
		userService.saveUserDetails(user);
	}
	
	@GetMapping("/getAllUser")
	public List<User> getAllUserData() {
		
		List<User> listOfUsers = userService.getAllUserData();
		
		return listOfUsers;
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteUser(@PathVariable("id") int userid) throws UserNotFountException{
		System.out.println("user id "+userid);
		
		userService.deleteUserById(userid);
	
	}
	
}
