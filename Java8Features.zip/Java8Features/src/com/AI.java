package com;

@FunctionalInterface
public interface AI {
	
	int add(int a,int b);
	
	
}
