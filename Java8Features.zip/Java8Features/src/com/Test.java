package com;

public class Test {
	
	public void test() {

		AI ai = (a,b) -> {
			
			System.out.println("hahhahah");
			return a+b;
		
		} ; 
		
		int sum = ai.add(10, 20);
		System.out.println(sum);
		
		//
		
		AI ai2 = (a,b) -> {
			
			System.out.println("hahhahah");
			return a*b;
		
		} ; 
		
		int multi = ai2.add(10, 20);
		System.out.println(multi);
		
	}
	
	
	public static void main(String[] args) {
		Test t = new Test();
		 t.test();
	}	

}
