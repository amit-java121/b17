package com;

public class Test2 {
	
	public static void main(String[] args) {
		
		CheckValue cv = (value1,value2) -> value1.equalsIgnoreCase(value2);
		
		System.out.println(cv.test("test", "test1"));
		
	}

}
