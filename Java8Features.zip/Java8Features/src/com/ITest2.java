package com;

public interface ITest2 {
	
	void m1();
	
	default void m2() {
		System.out.println("m2 called::");
	}
	
	static void m3() {
		System.out.println("m3 called::");
	}

}
