package com.mref;

public class TestAdd {
	
	
	public int addUsingMref(int a,int b) {
		
		return a+b;
	}
	
	public static void main(String[] args) {
		TestAdd ta = new TestAdd();
		
//		IAdd add = (a,b) -> a+b;
//		int summ = add.add(10, 5);
//		System.out.println(summ);
		
		IAdd ad = ta::addUsingMref;
		int sum= ad.add(10, 20);
		System.out.println(sum);
		
	}

}
