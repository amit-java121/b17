package com.mref;

public interface IAdd {
	
	int add(int a,int b);

}
