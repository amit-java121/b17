package com.mref;

import java.util.List;
import java.util.Optional;

public class TestOptional {
	
	public Optional<List<String>> fetchDataFromDB() {
		List<String> list = null;
		
		try {
		// list = new ArrayList<String>();
		 //error occured
//		list.add("abc");
//		list.add("xyz");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return Optional.ofNullable(list);
	}
	
	public void filterData() {

		Optional<List<String>> ListOfUser = fetchDataFromDB();

		if (ListOfUser.isPresent() && ListOfUser.isEmpty() ) {

			List<String> list = ListOfUser.get();

			if (list.get(0).equals("abc")) {
				System.out.println("if codition exeucted::");
			} else {
				System.out.println("else block executed::");
			}

		}
		System.out.println("outer side if");
		
	}
	
	public static void main(String[] args) {
		TestOptional to = new TestOptional();
		to.filterData();
	}

}
