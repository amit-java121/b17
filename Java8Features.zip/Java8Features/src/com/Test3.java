package com;

public class Test3 implements ITest,ITest2{

	@Override
	public void m1() {
		
		
	}
	
	
	public void test() {
		m2();
		ITest.m3();
	}
	
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		ITest.super.m2();
	}


	public static void main(String[] args) {
		Test3 test = new Test3();
		test.test();
	}

}
