package com;

public interface CheckValue {
	
	boolean test(String value1,String value2);

}
