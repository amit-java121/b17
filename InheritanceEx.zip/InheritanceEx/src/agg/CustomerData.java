package agg;

public class CustomerData {
	
	public static Customer setCustomerData() {
		
		Customer customer = new Customer();
		customer.setCustomerId(1000);
		customer.setCustomerName("xpertit");
		customer.setGender("male");
		
		Address address = new Address();
		address.setFlatNo(201);
		address.setSocietyName("annexe");
		address.setAreaName("Magarpatta");
		address.setCity("pune");
		address.setState("MH");
		
		customer.setAddress(address);
		
		return customer;
	}
	
	
	public static void printData() {
		Customer cust = setCustomerData();
		
		System.out.println(cust.getCustomerId());
		System.out.println(cust.getCustomerName());
		System.out.println(cust.getGender());
		
		Address add = cust.getAddress();
		
		System.out.println(add.getFlatNo());
		System.out.println(cust.getAddress().getSocietyName());
		System.out.println(cust.getAddress().getAreaName());
		System.out.println(cust.getAddress().getCity());
		System.out.println(cust.getAddress().getState());
		
		
	}
	
	public static void main(String[] args) {
		printData();
	}

}
