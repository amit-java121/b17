package agg;

public class Address {
	private int flatNo;
	private String societyName;
	private String areaName;
	private String city;
	private String state;
	private String coutnry;
	
	public int getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public String getSocietyName() {
		return societyName;
	}
	public void setSocietyName(String societyName) {
		this.societyName = societyName;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCoutnry() {
		return coutnry;
	}
	public void setCoutnry(String coutnry) {
		this.coutnry = coutnry;
	}
	
	

}
