package com;

public class A {
	
	int age =25;
	
	public void m1() {
		System.out.println("m1 called from class A");
	}

}
