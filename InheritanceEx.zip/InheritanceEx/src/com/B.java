package com;

public class B extends A{
	
	String name = "xpertit";

	public void m2() {
		System.out.println("m2 called from B");
	}
	
	
	
	public static void main(String[] args) {
		A a = new A();
		
		
		B b = new B();
		
		System.out.println(b.age);
		System.out.println(b.name);
		b.m1();
		b.m2();
	}
}
