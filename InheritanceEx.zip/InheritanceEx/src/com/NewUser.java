package com;

public class NewUser extends User{
	
	long adhaarNumber;

	public NewUser(int id, String userName, String userAddress, long voterCardNumber, int age, long adhaarNumber) {
		super(id, userName, userAddress, voterCardNumber, age);
		this.adhaarNumber = adhaarNumber;
	}
	
	

}
