package com;

public class User {
	 int id;
	 String userName;
	 String userAddress;
	 long voterCardNumber;
	 int age;
	
	public User(int id, String userName, String userAddress, long voterCardNumber, int age) {
		this.id = id;
		this.userName = userName;
		this.userAddress = userAddress;
		this.voterCardNumber = voterCardNumber;
		this.age = age;
	}
	
	
	

}
