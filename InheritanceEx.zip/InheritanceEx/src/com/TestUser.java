package com;

public class TestUser {
	
	
	public User prepareData() {
		User user = new User(100, "Ajay", "Pune", 191991919l, 30);
		
		System.out.println("prepareData called");
		return user;
	}
	
	
	public static void main(String[] args) {
		
		TestUser tu = new TestUser();
		User user1 = tu.prepareData();
		System.out.println(user1.id);
		System.out.println(user1.userName);
		System.out.println(user1.userAddress);
		System.out.println(user1.voterCardNumber);
		System.out.println(user1.age);
		
	}

}
