package com;

public class NewTestUser {
	
	
	
	public static void main(String[] args) {
		NewUser nUser = new NewUser(1000, "Bijay", "Mumbai", 191991991l, 39, 18818188881l);
		
		System.out.println(nUser.adhaarNumber);
	}

}
