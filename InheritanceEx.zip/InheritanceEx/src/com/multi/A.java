package com.multi;

public class A {
	
	int aa =10;
	
	public void m1() {
		System.out.println("m1 callled from class A");
	}

}
