package com.multi;

public class B extends A{

	int bb =20;
	
	public void m2() {
		System.out.println("m2 callled from class B");
	}
	
}
