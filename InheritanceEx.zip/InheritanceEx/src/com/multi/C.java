package com.multi;

public class C extends B{

	int cc =30;
	
	public void m3() {
		System.out.println("m3 callled from class C");
	}
	
	
	public static void main(String[] args) {
		
		A a = new A();
		
		
		B b = new B();
		
		
		
		C c = new C();
		
      c.m1();
      c.m2();
      c.m3();
		
		
	}
	
}
