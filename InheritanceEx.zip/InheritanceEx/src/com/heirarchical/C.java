package com.heirarchical;

public class C extends A{
	
	int cc =30;
	
	public void m3() {
		System.out.println("m3 callled from class C");
	}

	public static void main(String[] args) {
		 C c = new C();
		
	}
}
