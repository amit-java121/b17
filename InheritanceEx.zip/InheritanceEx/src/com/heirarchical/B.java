package com.heirarchical;

public class B extends A{

	int bb =10;
	
	public void m2() {
		System.out.println("m2 callled from class B");
	}
	
	
	public static void main(String[] args) {
		//B b = new B();
		
		//A a = new A();
		
		A a = new B();//
		
		//B b = new A();
		
		
	}
}
