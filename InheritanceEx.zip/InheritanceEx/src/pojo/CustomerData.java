package pojo;

public class CustomerData {
	
	
	public Customer setCustomerData() {
		
		Customer customer  = new Customer();
		customer.setCutomerId(10010);
		customer.setCustomerName("xpertit");
		customer.setCityName("pune");
		customer.setCountry("India");
		customer.setState("MH");
		customer.setPincode(411013);
		
		return customer;
		
	}

}
