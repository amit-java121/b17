package pojo;

public class PrintCustomerData {
	
	public Customer printData() {
		CustomerData cd = new CustomerData();
		Customer customer= cd.setCustomerData();
		
//		System.out.println(customer.getCutomerId());
//		System.out.println(customer.getCustomerName());
//		System.out.println(customer.getCityName());
//		System.out.println(customer.getCountry());
//		System.out.println(customer.getState());
//		System.out.println(customer.getPincode());

		customer.setState("Delhi");
		
		return customer;
	}
	
	
//	public static void main(String[] args) {
//	
//		PrintCustomerData pcd = new PrintCustomerData();
//		pcd.printData();
//	}

}
