package pojo;

public class CustomerDataBase {
	
	public static void main(String[] args) {
		
		PrintCustomerData customerData = new PrintCustomerData();
		
		Customer cust = customerData.printData();
		
		System.out.println(cust.getCutomerId());
		System.out.println(cust.getCustomerName());
		System.out.println(cust.getCityName());
		System.out.println(cust.getCountry());
		System.out.println(cust.getState());
		System.out.println(cust.getPincode());
		
		
	}

}
