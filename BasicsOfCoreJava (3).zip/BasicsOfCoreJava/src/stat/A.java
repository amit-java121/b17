package stat;

public class A {

	
	public void m1() {
		System.out.println("m1 called");
	}
	
	public static void m2() {
		System.out.println("m1 called");
	}
}
