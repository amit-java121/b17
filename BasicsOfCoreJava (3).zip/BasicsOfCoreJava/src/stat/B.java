package stat;

public class B {
	
	public void test() {
		A a = new A();
		a.m1();
	}
	
	public void testB() {
		test();
		m3();
		A.m2();
	}
	
	
	public static void m3() {
		
	}
	
	public static void main(String[] args) {
		//m3();
		B b = new B();
		b.testB();
	}

	
	
}
