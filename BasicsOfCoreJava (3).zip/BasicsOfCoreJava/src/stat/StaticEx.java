package stat;

public class StaticEx {
	
	String name;
	static int age; 
	
	
	public StaticEx() {
		age = 30;
		System.out.println("const called "+age);
	}
	
	static {
		age = 25;
		System.out.println("static block callled "+age);
	}
	
	public static void test(){
		
		System.out.println("test method called "+age);
	}
	
	
	public static void main(String[] args) {
		test();
		
	}

}
