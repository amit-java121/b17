package stat;

public class ReverseEx {
	
	public void reverse() {
		
		int[] array = {10,20,30,40,50,60}; //50,40,30,20,10
	   
		for(int i=array.length-1 ; i>=0; i--) {
			System.out.println(array[i]);
		}
		
		
	}
	
	public static void main(String[] args) {
		ReverseEx re = new ReverseEx();
		re.reverse();
	}

}
