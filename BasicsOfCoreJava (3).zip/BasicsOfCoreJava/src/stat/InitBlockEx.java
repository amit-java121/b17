package stat;

public class InitBlockEx {
	
	int age;
	String name;
	public InitBlockEx(int age) {
		this.age = age;
		System.out.println("const called::");
	}
	
	static {
		System.out.println("static block called::");
	}
	
	{
		name = "Amit";
		System.out.println("init block called");
	}
	
	
	public static void main(String[] args) {
		InitBlockEx ib = new InitBlockEx(25);
		
		System.out.println(ib.age);
		System.out.println(ib.name);
		
	}

}
