package stat;

public class TestStaticEx {
	
	 static int count = 0;
	
	public TestStaticEx() {
		count++;
		
		System.out.println(count);
	}
	
	
	public static void main(String[] args) {
		TestStaticEx ts = new TestStaticEx();
		
		TestStaticEx ts2 = new TestStaticEx();
		TestStaticEx ts3 = new TestStaticEx();
		
	}

}
