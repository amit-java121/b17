package loops;

public class ContinueEx {

	public static void main(String[] args) {
		
		
		for(int a=1; a<=2; a++) {
			
			System.out.println("a= "+a);
			
			for(int b=1; b<=2; b++) {
				System.out.println("b= "+b);
				
				if(b==1) {
					System.out.println("our required number found");
					continue;
				}
				
				System.out.println("after if condition::");
			}
			
			
		}
		
	}
}
