package loops;

public class WhileLoopEx {
	
	public static void main(String[] args) {
		int i=0;
		
		while(i<5) {
			System.out.println("i "+i);
			
			i++;
		}
		
		
		boolean flag = true;
		
		while(flag) {
			System.out.println("logic executed:: ");
			int a=10;
			if(a==10) {
				flag = false;
			}
			
		}
	}

}
