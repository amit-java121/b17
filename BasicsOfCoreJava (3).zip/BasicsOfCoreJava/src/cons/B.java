package cons;

public class B {

	int age;
	String name;
	int id;
	
//	public B() {
//		this(10);
//		System.out.println("default :::");
//	}

//	public B(int age) {
//		this(25,30);
//		System.out.println("single param :::");
//	}

//	public B(int age1,String str,int id1) {
//		name= str;
//		age = age1;
//		id = id1;
//	
//		System.out.println("two param :::"+age+" "+id);
//	}
	
	
	public B(String name1, int id1) {
		//super();
		name = name1;
		id = id1;
		System.out.println("logic::::"); 
	}


	public static void main(String[] args) {
		//B b = new B();
		B bb = new B("abc",50);
		
		System.out.println(bb.age);
		System.out.println(bb.name);
		System.out.println(bb.id);
		//B b1 = new B(10,"abc");
		//B b2 = new B(100);
	}

}
