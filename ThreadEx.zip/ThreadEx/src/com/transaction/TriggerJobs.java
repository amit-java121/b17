package com.transaction;

public class TriggerJobs {
	
	public static void main(String[] args) {
		
		PrintNumber pn = new PrintNumber();

		Job1 job1 = new Job1(pn);
		job1.start();
		
		Job2 job2 = new Job2(pn);
		job2.start();
		
	}

}
