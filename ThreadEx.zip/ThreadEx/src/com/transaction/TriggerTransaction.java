package com.transaction;

public class TriggerTransaction {
	
	public static void main(String[] args) {
		
		Transaction tr = new Transaction();
		  tr.start();
		  tr.setName("HDFC Bank");
		  
		  Transaction tr2 = new Transaction();
		  tr2.start();
		  tr2.setName("HDFC ATM");
		  
		  
		  
	}

}
