package com.transaction;

public class Transaction extends Thread{
	
	static int availableAmt = 10000;
	
	@Override
	public void run() {
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0; i<30; i++) {
		 withdraw(500);
	   }
	}
	
	
	private static synchronized void withdraw(int amt) {
		System.out.println("trying to withdraw :"+Thread.currentThread().getName());
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		if(availableAmt > 500) {
			availableAmt = availableAmt-amt;
		
			System.out.println("available balance : "+availableAmt+" thread "+Thread.currentThread().getName());
		}else {
			System.out.println("not sufficient balance "+Thread.currentThread().getName());
		}
		
	}

}

