package com;

public class TriggerJob {
	
	public static void main(String[] args) throws InterruptedException {
	
		System.out.println("before first loop:"+Thread.currentThread().getName());
		
		for(int i = 0; i<10; i++) {
			System.out.println("i= "+i);
		}
		
		Job1 job = new Job1();
		job.start();
		job.setName("hdfc bank");
		job.join();
		
//		Job1 job1 = new Job1();
//		job1.start();
		
		Job2 job2 = new Job2();
		job2.setName("SBI bank");
		job2.start();
		
		System.out.println("end loop: "+Thread.currentThread().getName());
		for(int i = 20; i<30; i++) {
			System.out.println("ii= "+i);
		}
		
	}

}
