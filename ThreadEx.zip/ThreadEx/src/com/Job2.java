package com;

public class Job2 extends Thread{
	
	@Override
	public void run() {
		System.out.println("job2 : "+Thread.currentThread().getName());
		for(int i=0;i<5; i++) {
			System.out.println("job2 executed: "+i);
		}
	} 

}
