package com;

public class Job1 extends Thread{
	
	@Override
	public void run() {
		System.out.println("Job : "+Thread.currentThread().getName());
		
		for(int i = 10;i<20; i++) {
			System.out.println(i);
		}
	}

}
