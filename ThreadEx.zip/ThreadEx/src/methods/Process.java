package methods;

public class Process {
	
	public void test() throws InterruptedException {
		System.out.println("thread entered::"+Thread.currentThread().getName());
		synchronized (this) {
			wait();
		}
		
		System.out.println("thread resume....");
		System.out.println("code executed:::");
	}
	
	public void test2() throws InterruptedException{
		System.out.println("thread entered "+Thread.currentThread().getName());
		
		Thread.sleep(5000);
		
		synchronized (this) {
			notify();
		}
		System.out.println("thread came out :::");
		
	}

}
