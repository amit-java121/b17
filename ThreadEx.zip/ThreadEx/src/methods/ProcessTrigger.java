package methods;

public class ProcessTrigger {
	
	public static void main(String[] args) {
		
		Process p = new Process();
		
		
		Thread th = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					p.test();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		
		th.start();
		
		Thread th2 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					p.test2();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		th2.start();
		
		
	}

}
