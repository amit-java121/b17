package com;

public class B{

//	public void m2() {
//		
//	}
}
