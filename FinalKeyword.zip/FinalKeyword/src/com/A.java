package com;

public final class A {
	
	public final void m2() {
		
	}

}
