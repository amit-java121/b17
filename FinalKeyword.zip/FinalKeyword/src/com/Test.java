package com;

public class Test {
	
	private final int age;
	private String name;
	
	
	public Test() {
		age =35;
	}
	
	public void m1() {
		//age  =40;
		name = "abc";
	}

}
