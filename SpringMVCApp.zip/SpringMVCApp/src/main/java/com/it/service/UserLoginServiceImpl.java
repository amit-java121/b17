package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserLoginDao;
import com.it.model.User;

@Service
public class UserLoginServiceImpl implements IUserLoginService{
	
	@Autowired
	IUserLoginDao loginDao;

	public boolean verifyUserCredentilas(String username, String password) {

		User user = loginDao.getUserDetailsByEmailId(username);
		
		if(user != null && user.getUserPass().equals(password) ) {
			return true;
		}
		
		return false;
	}

	public boolean saveUserDetails(User user) {
		
		return loginDao.saveUserData(user);
	}

	public List<User> getAllEmpList() {
		
		return loginDao.getAllEmpList();
	}

}
