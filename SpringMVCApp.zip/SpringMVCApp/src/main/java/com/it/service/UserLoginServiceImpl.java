package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.IUserLoginDao;

@Service
public class UserLoginServiceImpl implements IUserLoginService{
	
	@Autowired
	IUserLoginDao loginDao;

	public boolean verifyUserCredentilas(String username, String password) {

		loginDao.getUserDetailsByEmailId(username);
		
		return false;
	}

}
