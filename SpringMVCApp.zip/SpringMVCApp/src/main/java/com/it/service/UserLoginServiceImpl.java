package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserLoginDao;
import com.it.model.User;

@Service
@Transactional
public class UserLoginServiceImpl implements IUserLoginService{
	
	@Autowired
	IUserLoginDao loginDao;

	public boolean verifyUserCredentilas(String username, String password) {

		User user = loginDao.getUserDetailsByEmailId(username);
		
		if(user != null && user.getUserPass().equals(password) ) {
			return true;
		}
		
		return false;
	}

}
