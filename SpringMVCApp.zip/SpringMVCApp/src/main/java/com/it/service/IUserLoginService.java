package com.it.service;

import java.util.List;

import com.it.model.User;

public interface IUserLoginService {

	boolean verifyUserCredentilas(String username, String password);

	boolean saveUserDetails(User user);

	List<User> getAllEmpList();

	void deleteUserById(int userId);

}
