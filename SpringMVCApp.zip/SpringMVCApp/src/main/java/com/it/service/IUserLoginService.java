package com.it.service;

import com.it.model.User;

public interface IUserLoginService {

	boolean verifyUserCredentilas(String username, String password);

	boolean saveUserDetails(User user);

}
