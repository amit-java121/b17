package com.it.service;

public interface IUserLoginService {

	boolean verifyUserCredentilas(String username, String password);

}
