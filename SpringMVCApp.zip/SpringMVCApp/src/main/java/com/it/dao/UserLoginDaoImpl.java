package com.it.dao;

import com.it.model.User;

public class UserLoginDaoImpl implements IUserLoginDao{

	public User getUserDetailsByEmailId(String username) {
		// TODO Auto-generated method stub
		
		return null;
	}

}
