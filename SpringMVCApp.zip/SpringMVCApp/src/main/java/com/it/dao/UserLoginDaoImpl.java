package com.it.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class UserLoginDaoImpl implements IUserLoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	public User getUserDetailsByEmailId(String username) {

		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery("from User where userEmail=?");
		User user = (User)query.setParameter(0, username).getSingleResult();
		
		return user;
	}
	
	public void saveUserDetails(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
	}
	
	

}
