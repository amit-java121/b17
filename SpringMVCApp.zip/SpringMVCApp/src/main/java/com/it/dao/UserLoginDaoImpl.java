package com.it.dao;

import org.springframework.stereotype.Service;


public class UserLoginDaoImpl implements IUserLoginDao{

}
