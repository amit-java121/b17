package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.it.model.User;

@Repository
@Transactional
public class UserLoginDaoImpl implements IUserLoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	public User getUserDetailsByEmailId(String username) {

		Session session = sessionFactory.getCurrentSession();
		
		Query query = session.createQuery("from User where userEmail=?");
		User user = (User)query.setParameter(0, username).getSingleResult();
		
		return user;
	}

	public boolean saveUserData(User user) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		
		try {
		session.save(user);
		tr.commit();
		return true;
		
		}catch(Exception e) {
			//e.printStackTrace();
			tr.rollback();
			session.close();
			return false;
		}
		
	}

	public List<User> getAllEmpList() {

		Session session = sessionFactory.openSession();
		
		List<User> listEmp = session.createCriteria(User.class).list();
		
		return listEmp;
	}

	public void deleteUser(int userId) {
		
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		User user = session.get(User.class, userId);
		session.delete(user);
		tr.commit();
		
	}
	
	

}
