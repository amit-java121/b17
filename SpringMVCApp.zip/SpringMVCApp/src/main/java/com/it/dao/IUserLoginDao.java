package com.it.dao;

public interface IUserLoginDao {

}
