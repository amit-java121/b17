package com.it.dao;

import com.it.model.User;

public interface IUserLoginDao {

	User getUserDetailsByEmailId(String username);

	boolean saveUserData(User user);

}
