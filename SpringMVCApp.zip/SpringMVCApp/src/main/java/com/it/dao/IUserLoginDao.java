package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface IUserLoginDao {

	User getUserDetailsByEmailId(String username);

	boolean saveUserData(User user);

	List<User> getAllEmpList();

}
