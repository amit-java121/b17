package com.it.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PaymentController {
	

}
