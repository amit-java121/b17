package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.it.service.IUserLoginService;

@Controller
public class UserLoginController {
	
	
	@Autowired
	IUserLoginService loginService;
	
	@GetMapping("/")
	public String loginPage() {
		System.out.println("loginPage called::");
		return "login";
	}

}
