package com.it.controller;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.IUserLoginService;

@Controller
@SessionAttributes("userModel")
public class UserLoginController {
	
	
	@Autowired
	IUserLoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("loginPage called::");
		return "login";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("username") String username,@RequestParam("password") String password,Model model,HttpSession session) {
		System.out.println("login method called:: user name : "+username+" password:: "+password);
		
		boolean flag = loginService.verifyUserCredentilas(username,password);
		
		if(flag) {
			session.setAttribute("userEmail", username);
			return "redirect:/getEmpList";
		}
		model.addAttribute("message", "Your user name and password is incorrect please try again::");
		return "login";
	}
	
	@GetMapping("/register")
	public ModelAndView registerPage() {
		System.out.println("registerpage () :::");
		ModelAndView model = null;
			 model =  new ModelAndView("userForm", "user", new User());
		return model;
	}
	
	
	@PostMapping("/save")
	public String saveUserDetails(@ModelAttribute("userModel") User user,Model model) {
		System.out.println("user:: "+user.toString());
		boolean flag = loginService.saveUserDetails(user);
		//ModelAndView model = null;
		
		if(user.getUserId() > 0) {
			return "redirect:/getEmpList";
		}
		
		if(flag) {
			 //model1.addAttribute("message", "User data saved successfully!,please login");
			 //model =  new ModelAndView("login");
			 model.addAttribute("message", "User data saved successfully!,please login");
			 return "login";
		}else {
			
			 //model =  new ModelAndView("userForm", "user",user);
			model.addAttribute("user", user);
			 model.addAttribute("message", "User data not saved successfully!,please try again");
			 return "userForm";
		}
		
	}
	
	@GetMapping("/getEmpList")
	public String getEmpList(Model model) {
		
		List<User> userList = loginService.getAllEmpList();
		System.out.println(userList.toString());
		model.addAttribute("uList", userList);
		return "showUserData";
	}
	
	@GetMapping("/delete")
	public String deleteUserRecord(@RequestParam("id") int userId,@RequestParam("email") String emailToBeDeleted,Model model,HttpServletRequest request) {
		System.out.println("id "+userId);
		
		HttpSession session = request.getSession(false);
		String userName = (String)session.getAttribute("userEmail");
		System.out.println("session user name "+userName);
		boolean flag = false; 
		
		if(emailToBeDeleted.equalsIgnoreCase(userName)) {
			
			List<User> userList = loginService.getAllEmpList();
			System.out.println(userList.toString());
			model.addAttribute("uList", userList);
			model.addAttribute("message", "This is loggedin user you can not delete!!");
			return "showUserData";
			
		}else {
			 flag = loginService.deleteUserById(userId);
			 
			 if(flag) {
					return "redirect:/getEmpList";
				}else {
				
				List<User> userList = loginService.getAllEmpList();
				System.out.println(userList.toString());
				model.addAttribute("uList", userList);
				model.addAttribute("message", "User record is not deleted!!!");
				return "showUserData";
				}
			 
		}
		
	}
	
	@GetMapping("/edit")
	public ModelAndView editUserRecord(@RequestParam("empId") int userId) {
		System.out.println("id "+userId);
		User user = loginService.editUserById(userId);

		ModelAndView model = null;
		model =  new ModelAndView("userForm", "user", user);
		 
		 return model;
	}
	
	@ModelAttribute("userModel")
	public User getUserModel() {
		
		return new User();
	}
	
	@GetMapping("/test")
	public void test(@SessionAttribute("userModel") User user) {
		System.out.println("print user object from session "+user);
	}

}
