package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.IUserLoginService;

@Controller
public class UserLoginController {
	
	
	@Autowired
	IUserLoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("loginPage called::");
		return "login";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("username") String username,@RequestParam("password") String password,Model model) {
		System.out.println("login method called:: user name : "+username+" password:: "+password);
		
		boolean flag = loginService.verifyUserCredentilas(username,password);
		if(flag) {
			return "showUserData";
		}
		model.addAttribute("message", "Your user name and password is incorrect please try again::");
		return "login";
	}
	
	

}
