package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.IUserLoginService;

@Controller
public class UserLoginController {
	
	
	@Autowired
	IUserLoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("loginPage called::");
		return "login";
	}
	
	@GetMapping("/login")
	public void login(@RequestParam("username") String username,@RequestParam("password") String password) {
		System.out.println("login method called:: user name : "+username+" password:: "+password);
		
		loginService.verifyUserCredentilas(username,password);
	}

}
