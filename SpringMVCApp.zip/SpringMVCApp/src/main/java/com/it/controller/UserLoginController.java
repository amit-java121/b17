package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.IUserLoginService;

@Controller
public class UserLoginController {
	
	
	@Autowired
	IUserLoginService loginService;
	
	@GetMapping("/")
	public String homePage() {
		System.out.println("loginPage called::");
		return "login";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("username") String username,@RequestParam("password") String password,Model model) {
		System.out.println("login method called:: user name : "+username+" password:: "+password);
		
		boolean flag = loginService.verifyUserCredentilas(username,password);
		if(flag) {
			return "showUserData";
		}
		model.addAttribute("message", "Your user name and password is incorrect please try again::");
		return "login";
	}
	
	@GetMapping("/register")
	public ModelAndView registerPage() {
		System.out.println("registerpage () :::");
		ModelAndView model = null;
			 model =  new ModelAndView("userForm", "user", new User());
		return model;
	}
	
	
	@PostMapping("/save")
	public ModelAndView saveUserDetails(@ModelAttribute User user,Model model1) {
		System.out.println("user:: "+user.toString());
		boolean flag = loginService.saveUserDetails(user);
		ModelAndView model = null;
		
		
		if(flag) {
			 model1.addAttribute("message", "User data saved successfully!,please login");
			 model =  new ModelAndView("login");
		
		}else {
			model1.addAttribute("message", "User data not saved successfully!,please try again");
			 model =  new ModelAndView("userForm", "user",user);
		}
		
		return model;
	}
	

}
