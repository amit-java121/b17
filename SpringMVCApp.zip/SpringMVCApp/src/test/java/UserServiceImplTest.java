import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.it.service.UserLoginServiceImpl;

public class UserServiceImplTest {
	
	@BeforeClass
	public static void loadStaticData() {
		System.out.println("beforeClass annotation called::");
	}
	
	@Before
	public void setUp() {
		System.out.println("database connection setup is done::");
	}
	
	@Test
	public void testAddition() {
		
		UserLoginServiceImpl userLoginServiceImpl = new UserLoginServiceImpl();
		
		int sum = userLoginServiceImpl.add(10, 5);
		
		assertEquals(15, sum);
		
	}
	
	@Test
	public void testUserCredentials() {
		System.out.println("testUserCredentials called::");
		UserLoginServiceImpl userLoginServiceImpl = new UserLoginServiceImpl();
		boolean flag = userLoginServiceImpl.checkUserCredentilas("amit@gmail.com", "amit");
		
		assertTrue(flag);
		
	}
	
	
	@Test
	public void testUserCredentialsWrongData() {
		System.out.println("testUserCredentials called::");
		UserLoginServiceImpl userLoginServiceImpl = new UserLoginServiceImpl();
		boolean flag = userLoginServiceImpl.checkUserCredentilas("amit@gmail.com", "amit123");
		
		assertFalse(flag);
		
	}
	
	@After
	public void tearDown() {
		System.out.println("afetr annotation called::");
	}
	
	@AfterClass
	public static void clearStaticData() {
		System.out.println("afterClass annotation called::");
	}

}
