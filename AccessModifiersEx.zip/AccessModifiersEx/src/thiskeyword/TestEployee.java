package thiskeyword;

public class TestEployee {
	
	public static void main(String[] args) {
		
		Employee employee = new Employee(100, "Sunil", "pune");
		
		
		System.out.println(employee.getEmpId());
		System.out.println(employee.getEmpName());
		System.out.println(employee.getEmpAddress());
	}

}
