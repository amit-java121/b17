package com;

public class Customer {
	
	private int age =25;
	
	private void add() {
		
	}
	
	public Customer() {
		
	}
	
	public static void main(String[] args) {
		Customer c = new Customer();
		c.add();
	}

}
