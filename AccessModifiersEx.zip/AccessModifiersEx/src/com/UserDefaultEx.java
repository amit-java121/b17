package com;

public class UserDefaultEx {
	
	int id =1010;
	
	void test() {
		
	}
	
	public UserDefaultEx(){
		
	}

}
