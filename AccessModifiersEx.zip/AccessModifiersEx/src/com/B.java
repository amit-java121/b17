package com;

public class B {

	public int age;
	
	void m2() {
		
	}
	
	public B(){
		
	}
}
