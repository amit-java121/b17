package com;

public class TestProtected {
	
	protected int age;
	
	protected void m3() {
		
	}
	
	 protected TestProtected() {
		 
	 }

}
