package com;

public class ProtectedEx {
	
	protected String name = "xpertit";
	
	protected void test() {
		
	}
	
	protected ProtectedEx() {
		
	}

}
