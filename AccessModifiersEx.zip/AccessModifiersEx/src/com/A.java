package com;

public class A {
	
	private int age;
	
	private void m1() {
		
	}
	
	private A() {
		
	}
	
	
	public static void main(String[] args) {
		A a = new A();
		
	}

}
