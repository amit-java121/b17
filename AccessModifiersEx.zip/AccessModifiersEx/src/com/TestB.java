package com;

public class TestB {
	
	public void testB() {
		B b = new B();
		
	}

}
