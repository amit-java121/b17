package example;

public class Customer {
	
	public float intrestCalculation(int amount,int rateOfInterest,int time) {
		
		int intrestAmt= (amount*rateOfInterest*time)/100;
		System.out.println("intrest "+intrestAmt);
		
		float calculatedAmount = actualPrincipleAmount(intrestAmt,amount);
		
		return calculatedAmount;
	}

	private float actualPrincipleAmount(int intrestAmt,int amount) {
		
		float totalAmount = intrestAmt+amount;
		return totalAmount;
	} 
	


}
