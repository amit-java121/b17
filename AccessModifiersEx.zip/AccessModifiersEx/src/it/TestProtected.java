package it;

import com.ProtectedEx;

public class TestProtected extends ProtectedEx{
	
	
	
	public static void main(String[] args) {
		
		TestProtected tp = new TestProtected();
		
		//ProtectedEx pe = new ProtectedEx();
		
	}

}
