package it;

import com.B;

public class TestB {
	
	public void testB() {
		B b = new B();
	
		
	}

}
