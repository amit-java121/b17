package it;

import com.UserDefaultEx;

public class User extends UserDefaultEx{
	
	public static void main(String[] args) {
		UserDefaultEx ud = new UserDefaultEx();
		
	}

}
