package it;

import com.TestProtected;

public class TestProt extends TestProtected{
	
	
	
	
	
	public static void main(String[] args) {
		//TestProtected tp = new TestProtected();
		
		TestProt tp = new TestProt();
	
	}

}
