package com.orenda.lifesecure.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orenda.lifesecure.dao.LifeSecureLoginDao;

@Service
public class LifeSecureLoginServiceImpl implements LifeSecureLoginService{

	@Autowired
	LifeSecureLoginDao loginDao;
	
}
