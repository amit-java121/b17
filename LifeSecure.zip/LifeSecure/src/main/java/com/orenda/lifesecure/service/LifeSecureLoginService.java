package com.orenda.lifesecure.service;

public interface LifeSecureLoginService {

}
